<?php
require_once("classPage.php");
$page = new Page();
print $page->getTop();
print <<<EOF
<div class="container">
			<header>
			
				<h1><strong>Circulo</strong> con efecto al pasar el mouse</h1>
				<h2>Interesante efecto aplicado al paso del mouse</h2>
											
				<div class="support-note">
				</div>
				
			</header>
			
			<section class="main">
			
				<ul class="ch-grid">
					<li>
						<div class="ch-item">				
							<div class="ch-info">
								<div class="ch-info-front ch-img-1"></div>
								<div class="ch-info-back">
									<h3>Mouse</h3>
									<p>by MOMBARD <a href="#">Mirame en twitter</a></p>
								</div>	
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item">
							<div class="ch-info">
								<div class="ch-info-front ch-img-2"></div>
								<div class="ch-info-back">
									<h3>You</h3>
									<p>by MOMBARD <a href="#">View on Google+</a></p>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item">
							<div class="ch-info">
								<div class="ch-info-front ch-img-3"></div>
								<div class="ch-info-back">
									<h3>Love</h3>
									<p>by MOMBARD <a href="#">View on FACEBOOK</a></p>
								</div>
							</div>
						</div>
					</li>
				</ul>
				
			</section>
</div> 
<!-- end main content -->
EOF;
print $page->getBottom();
?>