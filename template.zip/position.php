<?php
require_once("classPage.php");
$page = new Page();
$page->titleExtra = "Donde estoy";
print $page->getTop();
print <<<EOF
<div id="mainContent">
<p>Mallorca.</p>
</div> <!-- end main content -->
<a href="http://maps.google.com/maps?q=Carrer Provença 1, Palma de Mallorca, España" target="_blank">Localizame  en Google Maps</a>
EOF;
print $page->getBottom();
?>