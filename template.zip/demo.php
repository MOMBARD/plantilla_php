<?php
require_once("classPage.php");
$page = new Page();
$page->titleExtra = "Demo CSS-PHP-JQuery-HTML";
print $page->getTop();
print <<<EOF
<div id="mainContent">
<p><a href="demo/index.html" target="_blank">Ver la Demo</a></p>

</div> <!-- end main content -->

EOF;
print $page->getBottom();
?>