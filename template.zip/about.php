<!-- CSS -->
		<link rel="stylesheet" href="css/style.css" type="text/css" media="screen" />
		<link rel="stylesheet" href="css/spring.css" type="text/css" media="screen" />
		<link rel="stylesheet" href="js/prettyPhoto/css/prettyPhoto.css" type="text/css" media="screen" />
		<!--[if IE 6]>
			<link rel="stylesheet" type="text/css" media="screen" href="css/ie-hacks.css" />
			<script type="text/javascript" src="js/DD_belatedPNG.js"></script>
			<script>
          		/* EXAMPLE */
          		DD_belatedPNG.fix('*');
        	</script>
		<![endif]-->
		<!-- ENDS CSS -->
				
		
		
		<!-- JS -->
		<script type="text/javascript" src="js/jquery_1.3.2.js"></script>
		<script type="text/javascript" src="js/jqueryui.js"></script>
		<script type="text/javascript" src="js/easing.js"></script>
		<script type="text/javascript" src="js/jquery.cycle.all.js"></script>
		<script type="text/javascript" src="js/filterable.pack.js"></script>
		<script type="text/javascript" src="js/prettyPhoto/js/jquery.prettyPhoto.js"></script>
		<script type="text/javascript" src="js/custom.js"></script>
		<!-- ENDS JS -->
		
		
		
		<!-- superfish -->
		<link rel="stylesheet" type="text/css" media="screen" href="css/superfish-custom.css" /> 
		<script type="text/javascript" src="js/superfish-1.4.8/js/hoverIntent.js"></script> 
		<script type="text/javascript" src="js/superfish-1.4.8/js/superfish.js"></script> 
		<!-- ENDS superfish -->


		
		<!-- Cufon -->
		<script src="js/cufon-yui.js" type="text/javascript"></script>
		<script src="js/bebas_400.font.js" type="text/javascript"></script>
		<script type="text/javascript">
			Cufon.replace('.custom', { fontFamily: 'bebas', hover: true });
		</script>
        <!-- /Cufon -->
        
        
		
		<!-- Prettyphotos -->
		<script type="text/javascript" charset="utf-8">
			$(document).ready(function(){
				$("a[rel^='prettyPhoto']").prettyPhoto();
			});
		</script>
		<!-- ENDS  Prettyphotos -->
		
<?php
require_once("classPage.php");
$page = new Page();
$page->titleExtra = "Acerca de";
print $page->getTop();
print <<<EOF
<div id="mainContent">
<h1>CREACION DE EFECTOS CON JQUERY-CSS-HTML5-PHP UNA PROGRAMACION PARA TODOS</h1>
<h2>MOMBARD---FJHDUQUE---PALMA DE MALLORCA-SIMPLE DEMOSTRACION DE FILTRO DE OPCIONES</h2>
<h2>Ejemplo de filtro de contenido</h2>
</div> <!-- end main content -->
<p>
<div id="main">
		
		
		
		<!-- filter -->
		<ul id="portfolio-filter">
	    	<li>FILTER: </li>
	    	<li><a href="#all">Todas</a></li>
	    	<li><a href="#cat-images">IMAGENES</a></li>
	    	<li><a href="#cat-flash">FLASH</a></li>
	    	<li><a href="#cat-video">VIDEO</a></li>
		</ul>
		<!-- filter -->
		
		
				             
		
		<!-- thumbs -->
		<ul id="portfolio-list" class="gallery">
		
			<li class="cat-images">
				<a href="img/dummies/dummy-big-image.jpg" rel="prettyPhoto[images]">
				<span></span>
				<img src="img/dummies/dummy-gallery-thumb.jpg" alt="Image" /></a>
				<em>Images</em>
			</li>
			
			<li class="cat-flash">
				<a  href="http://www.adobe.com/products/flashplayer/include/marquee/design.swf?width=792&amp;height=294" rel="prettyPhoto[flash]" title="Flash 10 demo">
				<span></span>
				<img src="img/dummies/dummy-gallery-thumb2.jpg" alt="Flash" /></a>
				<em>Flash movie</em>
			</li>
			
			<li class="cat-video">
				<a href="http://www.youtube.com/watch?v=49UCWUxLRO4" rel="prettyPhoto[videos]">
				<span></span>
				<img src="img/dummies/dummy-gallery-thumb3.jpg" alt="Video" /></a>
				<em>Video</em>
			</li>
			
			<li class="cat-images">
				<a href="img/dummies/dummy-big-image.jpg" rel="prettyPhoto[images]">
				<span></span>
				<img src="img/dummies/dummy-gallery-thumb.jpg" alt="Image" /></a>
				<em>Image</em>
			</li>
			
			<li class="cat-flash">
				<a  href="http://www.adobe.com/products/flashplayer/include/marquee/design.swf?width=792&amp;height=294" rel="prettyPhoto[flash]" title="Flash 10 demo">
				<span></span>
				<img src="img/dummies/dummy-gallery-thumb2.jpg" alt="Flash" /></a>
				<em>Flash movie</em>
			</li>
			
			<li class="cat-video">
				<a href="http://www.youtube.com/watch?v=49UCWUxLRO4" rel="prettyPhoto[videos]">
				<span></span>
				<img src="img/dummies/dummy-gallery-thumb3.jpg" alt="Video" /></a>
				<em>Video</em>
			</li>
			
			<li class="cat-images">
				<a href="img/dummies/dummy-big-image.jpg" rel="prettyPhoto[images]">
				<span></span>
				<img src="img/dummies/dummy-gallery-thumb.jpg" alt="Image" /></a>
				<em>Image</em>
			</li>
			
			<li class="cat-flash">
				<a  href="http://www.adobe.com/products/flashplayer/include/marquee/design.swf?width=792&amp;height=294" rel="prettyPhoto[flash]" title="Flash 10 demo">
				<span></span>
				<img src="img/dummies/dummy-gallery-thumb2.jpg" alt="Flash" /></a>
				<em>Flash movie</em>
			</li>
			
			<li class="cat-video">
				<a href="http://www.youtube.com/watch?v=49UCWUxLRO4" rel="prettyPhoto[videos]">
				<span></span>
				<img src="img/dummies/dummy-gallery-thumb3.jpg" alt="Video" /></a>
				<em>Video</em>
			</li>
			
			<li class="cat-images">
				<a href="img/dummies/dummy-big-image.jpg" rel="prettyPhoto[images]">
				<span></span>
				<img src="img/dummies/dummy-gallery-thumb.jpg" alt="Image" /></a>
				<em>Image</em>
			</li>
			
			<li class="cat-flash">
				<a  href="http://www.adobe.com/products/flashplayer/include/marquee/design.swf?width=792&amp;height=294" rel="prettyPhoto[flash]" title="Flash 10 demo">
				<span></span>
				<img src="img/dummies/dummy-gallery-thumb2.jpg" alt="Flash" /></a>
				<em>Flash movie</em>
			</li>
			
			<li class="cat-video">
				<a href="http://www.youtube.com/watch?v=49UCWUxLRO4" rel="prettyPhoto[videos]">
				<span></span>
				<img src="img/dummies/dummy-gallery-thumb3.jpg" alt="Video" /></a>
				<em>Video</em>
			</li>
			
								
			
		</ul>
		<!-- ENDS thumbs -->
		
		
		
EOF;
print $page->getBottom();
?>