<?php
require_once("classPage.php");
$page = new Page();
$page->type = "contact";
$page->titleExtra = "Contact Me";
print $page->getTop();
print <<<EOF
<div id="mainContent">
<h3>CONTACTAR CONMIGO ES FACIL</h3>
<p class="contactMethod">Email:mombard[at]gmail[dot]com</p>
<p class="contactMethod">Twitter: @MOMBARDDUQUE</p>
</div> 
<img src="imagenes/personal.jpg" alt="FJHDUQUE-MOMBARD">
<!-- end main content -->
<section class="body">
    
	    <form action="form.php" method="post" enctype="multipart/form-data">
	        
	        <h1 class="title">Contacta Conmigo</h1>
	        
		    <label></label>
		    <input name="name" required="required" placeholder="Su Nombre">
		    
		            
		    <label></label>
		    <input name="email" type="email" required="required" placeholder="Su Email">
		            
		    
		    <label></label>
		    <textarea name="message" cols="20" rows="5" required="required" placeholder="Mensaje"></textarea>
		    
		    		    
		    <input id="cancel" name="cancel" value="Cancelar" />
		            
		    <input id="submit" name="submit" type="submit" value="Enviar">
	        
	    </form>

    </section>


EOF;
print $page->getBottom();
?>