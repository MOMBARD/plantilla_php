<?php
require_once("classPage.php");
$page = new Page();
$page->titleExtra = "Demo Calendario Jquery-CSS-HTML5";
print $page->getTop();
print <<<EOF
<div id="mainContent">
<p>Demo Calendario CSS-HTML5</p>
</div> <!-- end main content -->
<a href="date/date.html" target="_blank">Ver el Calendario</a>
EOF;
print $page->getBottom();
?>